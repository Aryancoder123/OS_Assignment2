#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#define MAT_2DSYSCALL 451

void check_2DCopy(int rows,int cols,float *source_mat[][cols],float *dest_mat[][cols]){
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            if(source_mat[i][j]!=dest_mat[i][j]){
                printf("Error : LHS[%d] != RHS[%d]\n", i, i);
                return;
            }
        }
    }
    printf("Message : Success LHS = RHS \n");
}
int main(){
    int source_mat[][] = {{1,2,3},
                         {4,5,6},
                         {7,8,9}};
    int dest_mat[3][3];
    long sys_call_status;
    sys_call_status = syscall(MAT_2DSYSCALL,source_mat,dest_mat,3);
    if(sys_call_status!=EFAULT){
        printf("Message : System Call 452 successfuly invoked \n");
        check_2DCopy(3,3,source_mat,dest_mat);
    }
    return 0;
}