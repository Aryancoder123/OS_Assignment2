#include <linux/kernel.h>
#include <linux/syscalls.h>
SYSCALL_DEFINE3(heySyscall,int *src,int *dest,int len){
    float buffer[3][3];
    if(__copy_from_user(buffer,src,9)){
        return -EFAULT;
    }
    if(__copy_to_user(dest,buffer,sizeof(int)* (len))){
        return -EFAULT;
    }
}