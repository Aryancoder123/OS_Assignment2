#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
    int pid = fork();
    double result;
    int status;
    if(clock_gettime(CLOCK_REALTIME,&start)==-1){
			perror("Clock gettime");
			return EXIT_FAILURE;
	}
    if(pid==0){
        char *args[] = {"/root/bash1.sh",NULL};
        execvp(args[0],args);
    }
    else{
        waitpid(pid,&status,0);
        if(clock_gettime(CLOCK_REALTIME,&stop)==-1){
			perror("Clock gettime");
			return EXIT_FAILURE;
		}
        result = (stop.tv_sec-start.tv_sec) + (double) (stop.tv_nsec - start.tv_nsec)/(double) 1000000000L;
		printf("%lf\n",result);
        int pid2 = fork();
        if(clock_gettime(CLOCK_REALTIME,&start)==-1){
			perror("Clock gettime");
			return EXIT_FAILURE;
	       	}
        if(pid2==0){
            char *args2[] = {"/root/bash2.sh",NULL};
            execvp(args2[0],args2);
        }
        else{
            waitpid(pid2,&status,0);
            if(clock_gettime(CLOCK_REALTIME,&stop)==-1){
                perror("Clock gettime");
                return EXIT_FAILURE;
	       	}
            result = (stop.tv_sec-start.tv_sec) + (double) (stop.tv_nsec - start.tv_nsec)/(double) 1000000000L;
		printf("%lf\n",result);
            int pid3 = fork();
            if(clock_gettime(CLOCK_REALTIME,&start)==-1){
			perror("Clock gettime");
			return EXIT_FAILURE;
	       	}
            if(pid3==0){
                char *args3[] ={"root/bash3.sh",NULL};
                execvp(args3[0],args3);
            }
            if(clock_gettime(CLOCK_REALTIME,&stop)==-1){
			perror("Clock gettime");
			return EXIT_FAILURE;
	       	}
            result = (stop.tv_sec-start.tv_sec) + (double) (stop.tv_nsec - start.tv_nsec)/(double) 1000000000L;
		printf("%lf\n",result);
        }
    }
}
