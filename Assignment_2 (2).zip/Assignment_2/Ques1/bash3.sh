cd kernel3/linux-5.19.9
make -j2
sudo make modules_install
