cd kernel1/linux-5.19.9
make -j2
sudo make modules_install
